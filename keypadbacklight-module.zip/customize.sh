#!/system/bin/sh

set_perm $MODPATH/keypad.sh 0 0 0755
set_perm $MODPATH/service.sh 0 0 0755