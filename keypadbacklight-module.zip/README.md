# duoqin-f22-pro-keybacklight

Magisk Module for Duoqin F22 Pro to enable keypad backlight support.
